import React, {useState,useEffect} from 'react'
import Card from '../components/Card'

const Productos = () => {
  const [productos, setProductos] = useState([])
  useEffect(() => {
    fetch("https://dummyjson.com/products")
    .then(respuesta=>respuesta.json())
    .then(datos=>setProductos(datos.products))
  }, [])
  

  return (
    <section>
      <Card productos={productos}></Card>
    </section>
  )
}

export default Productos