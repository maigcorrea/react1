import React from 'react'

const Error = () => {
  return (
    <>
        <h1>ERROR 404</h1>
    </>
  )
}

export default Error