import React from 'react'

const Detalles = () => {
  return (
    <div>Detalles</div>
  )
}

export default Detalles