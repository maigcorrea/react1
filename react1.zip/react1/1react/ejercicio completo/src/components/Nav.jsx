import React from 'react'
import {Link} from 'react-router-dom'

const Nav = () => {
  return (
    <nav className='space-x-4 uppercase font-medium'>
      <Link to="/" className='enlaces'>Home</Link>
      <Link to="/productos" className='enlaces'>Productos</Link>
      <Link to="/contacto" className='enlaces'>Contacto</Link>
    </nav>
  )
}

export default Nav