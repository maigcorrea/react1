import React from 'react'

const Footer = () => {
  return (
    <footer className='bg-indigo-700 text-white p-5 text-center fixed w-full bottom-0'>
      <small>&copy; Todos los derechos no reservados</small>
    </footer>
  )
}

export default Footer