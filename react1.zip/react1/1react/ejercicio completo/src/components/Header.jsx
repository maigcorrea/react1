import React from 'react'
import logo from '../assets/logo.svg'
import Nav from './Nav'

const Header = () => {
  return (
    <header className='bg-indigo-700 px-[20px] py-[40px] text-white flex items-center justify-between'>
      <div>
        <img src={logo} alt="" className='max-h-[50px]' />
      </div>

      <Nav />
    </header>
  )
}

export default Header